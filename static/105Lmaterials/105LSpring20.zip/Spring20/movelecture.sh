#!/bin/sh

if [ -d "$1" ]; then
	cd "$1"
	mv "$1.tex" "$2.tex"
	rm "$1".*
	# Compile twice for references
	pdflatex -interaction=nonstopmode -shell-escape -synctex=1 "$2.tex"
	pdflatex -interaction=nonstopmode -shell-escape -synctex=1 "$2.tex"
	cd ..
	mv "$1" "$2"
else
	echo Directory "$1" not found!
fi
