#!/bin/bash

for dir in *-*; do
	cd $dir;
	rm *.pdf
	for texfile in *-*.tex; do
		# Compile each file twice for references
		echo "Compiling" $texfile "..."
		pdflatex  -interaction=nonstopmode -file-line-error -shell-escape -synctex=1 $texfile | grep ".*:[0-9]*:.*";
		pdflatex  -interaction=nonstopmode -file-line-error -shell-escape -synctex=1 $texfile | grep ".*:[0-9]*:.*";
		echo "Done!"
	done
	rm *.{aux,auxlock,log,out,synctex.gz,tex~}  > /dev/null 2>&1
	cd ..;
done
